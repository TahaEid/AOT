<?php

namespace App\Http\Controllers\user;

use App\Http\Controllers\Controller;
use App\Models\User;
use Illuminate\Http\Request;
use Inertia\Inertia;



class UserController extends Controller
{
    public function index(Request $request)
    {
        $data = User::all()->map(function($user){
            return [
                'id' => $user->id,
                'name' => $user->name,
                'email' => $user->email,
                'can' => [
                    'edit_ticket' => $user->can('edit ticket'),
                ],
            ];
        });
        return Inertia::render('Users/Index', [
            'data' => $data,
            'can' => auth()->user()->can('publish ticket'),
        ]);
    }
}
