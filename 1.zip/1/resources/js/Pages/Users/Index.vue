<template>
  <app-layout>
    <div><h1>Can the logged-in user publish articles?  {{can}}</h1></div>
    <div class="">
      <table class="shadow-lg border m-4 rounded-xl">
        <thead>
        <tr class="bg-indigo-100">
          <th class="py-2 px-4 border">Name</th>
          <th class="py-2 px-4 border">Email</th>
          <th class="py-2 px-4 border">Can Edit Articles</th>
        </tr>
        </thead>
        <tbody>
        <tr v-for="item in data" :key="item.id">
          <td class="py-2 px-4 border">{{item.name}}</td>
          <td class="py-2 px-4 border">{{item.email}}</td>
          <td class="py-2 px-4 border">{{item.can.edit_articles}}</td>
        </tr>
        </tbody>
      </table>
    </div>
  </app-layout>
</template><script>
    import AppLayout from '@/Layouts/AppLayout'

    export default {
        components: {
            AppLayout,
        },
        props: ['data','can'],
    }
</script>
